# ExoPlayer library #

The ExoPlayer library is split into multiple modules. See ExoPlayer's
[top level README][] for more information about the available library modules
and how to use them.

[top level README]: https://github.com/google/ExoPlayer/blob/release-v2/README.md
